# Weapon Detection with yolov3
## A machine learning model for weapon detection.

#### Requirements:
> - OpenCV
> - numpy
> - Python version 3.7 (tested)


> [click here to download weight file](https://drive.google.com/file/d/10uJEsUpQI3EmD98iwrwzbD4e19Ps-LHZ/view?usp=sharing)


<img src="https://github.com/Manish8798/Weapon-Detection-with-yolov3/assets/68828115/d527d813-6201-44eb-9073-d8ed4aae8aaa" width="350" height="250">
